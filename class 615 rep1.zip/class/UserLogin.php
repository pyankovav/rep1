<?php
session_start();
?>
<html>
<head>
</head>
<body>
<h2>Login here: </h2>
<form method="post" action="UserLogin.php">
<p> Username as your email: 
<input type="text" name="user" placeholder="username">
Password:
<input type="password" name="pwd" placeholder="password">
</p>
<p>
<input type="submit" value="Login"></p>
</form>


<?php

   // Connect to the database
       $con = mysqli_connect ('localhost', 'root', 'root', 'class')
 		or die('Error connecting to MySQL server.');

    // Grab the user login data
      $username = trim($_POST['user']);
      $password = trim($_POST['pwd']);

     if (!empty($username) && !empty($password)) {
        // Look up the username and password in the database
        $query = "SELECT * FROM customers WHERE username = '$username' AND password = '$password'";
        $result = mysqli_query($con, $query);

        if (mysqli_num_rows($result) == 1) {
           // Confirm the successful log-in
    	echo('<h2>Login Successful!</h2><h3>You are logged in as ' . $username . '.</h3>');
    	echo('<h2>Continue to the <a href="products.php">Products Page</a></h2>');
    	$_SESSION['username'] = $username;
    	setcookie('username', $row['username'], time() + (60 * 60 * 24 * 30));  // expires in 30 dclass
        }
        else {
          // The username/password are incorrect so set an error message
          	echo('<p> Sorry, you must enter a valid username and password to log in.');
         	echo('<h2> Create new account</h2>');
        	echo('<form method="post" action="newaccount.php">');
        	echo('<p> Email:<input type="text" name="email" placeholder="Email"></p><p>');
          	echo('<p> Create Password:<input type="password" name="pass" placeholder="password"></p><p>');
          	echo('<p> First Name:<input type="text" name="fname" placeholder="First Name"></p><p>');
          	echo('<p> Last Name:<input type="text" name="lname" placeholder="Last Name"></p><p>');        	echo('<p> Address:<input type="text" name="addess" placeholder="Address"></p><p>');
          	echo('<p> Zip:<input type="text" name="zip" placeholder="Zip code"></p><p>');
          	echo('<p> Phone:<input type="text" name="phone" placeholder="Phone"></p><p>');
          	echo('<p> Comments:<input type="textarea" name="comments" placeholder="Special Instructions"></p><p>');
			echo('<input type="submit" value="Create Account"></p></form>');
			
        	}
        	
      }
      else {
        // The username/password weren't entered so set an error message
        echo('<p> Sorry, you must enter a valid username and password to log in.');
         	echo('<h2> Create new account</h2>');
        	echo('<form method="post" action="newaccount.php">');
        	echo('<p> Email:<input type="text" name="email" placeholder="Email"></p><p>');
          	echo('<p> Create Password:<input type="password" name="pass" placeholder="password"></p><p>');
          	echo('<p> First Name:<input type="text" name="fname" placeholder="First Name"></p><p>');
          	echo('<p> Last Name:<input type="text" name="lname" placeholder="Last Name"></p><p>');        	echo('<p> Address:<input type="text" name="addess" placeholder="Address"></p><p>');
          	echo('<p> Zip:<input type="text" name="zip" placeholder="Zip code"></p><p>');
          	echo('<p> Phone:<input type="text" name="phone" placeholder="Phone"></p><p>');
          	echo('<p> Comments:<input type="textarea" name="comments" placeholder="Special Instructions"></p><p>');
			echo('<input type="submit" value="Create Account"></p></form>');
		
      }


?>
</body>
</html>
