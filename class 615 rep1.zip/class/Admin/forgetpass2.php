<?php
session_start();
?>

<?php
//Error Reporting
error_reporting(E_ALL);
ini_set('display_errors', '1');
?>

<html><head><title>Password Reset Page</title></head><body>
<h2> Reset your password here </h2>

<?php
	 $con = mysqli_connect ('localhost', 'root', 'root', 'class')
 		or die('Error connecting to MySQL server.');

			$password = trim($_POST['pwd']);
			$username = trim($_POST['user']);
			$query = "UPDATE admins SET admin_pwd = '$password' WHERE admin_user = '$username'";
			$result = mysqli_query($con, $query);
			$query1 = "SELECT admin_user, admin_pwd FROM admins WHERE admin_user = '$username'";
			$result1 = mysqli_query($con, $query1);
			if (mysqli_num_rows($result1) == 1) {
				while ($row = mysqli_fetch_array($result1)) {
				$pass = $row["admin_pwd"];
					if ($password == $pass){
						echo('<h2>Password Reset Successful!</h2><h3>
						<a href="admin_login.php">Click here to login again</a></h3>');
						
					}
					else {
						echo('<h2>Password Reset Unsuccessful!</h2><h3>
						<a href="forgetpass.php">Click here to reset it again</a></h3>');
					}
				}
			}

			
 ?>

</body></html>