<div id="pageTop">
  <div id="pageTopWrap">
    <div id="pageTopLogo">
      <a href="http://www.atyourservice.com">
        <img src="images/logo.png" alt="logo" title="At Your Service">
      </a>
    </div>
    <div id="pageTopRest">
      <div id="menu1">
        <div>
          <a href="logout.php">Log out</a>
        </div>
      </div>
      <div id="menu2">
        <div id="menu3">
          <a href="http://www.atyourservice.com">
            <img src="images/home.jpg" alt="home" title="Home">
          </a>
          <a href="forgetpass.php">Reset Password</a>
          <a href="updateinventory.php">Manage Inventory</a>
        </div>
      </div>
    </div>  
         <br />
         <br />
                  <br />
         <br />
                  <br />
         <br />
                  <br />
         <br />         <br />
         <br />
        </div>
      </div>
    </div>
  </div>
</div>

