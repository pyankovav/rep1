<?php
session_start();
if (!isset($_SESSION["manager"])) {
	header("location: admin_login.php");
	exit();
}
?>
<html><head><title>Admin Control Panel</title></head><body>
<?php include_once(""); //your website header template?>
<h1>Manage Inventory</h1>
<hr />
<h3>Manage Inventory</h3><h3 align="right"><a href="updateinventory.php#AddNewItem">+Add New Menu Item</a></h3>
<?php
$con = mysqli_connect ('localhost', 'root', 'root', 'class')
 		or die('Error connecting to MySQL server.');
$product_list="";

$sql= "SELECT * FROM Products";
$result = mysqli_query($con, $sql);
$itemcount = mysqli_num_rows($result);
if ($itemcount>0) {
	while ($row = mysqli_fetch_array($result)) {
     	$itemid = $row["ItemID"];
       	$itemTitle = $row["ItemTitle"];
        $itemDesc = $row["ItemDesc"];
       	$price = $row["Price"];
     	$category = $row["Category"];
      	$product_list = "$itemid - $itemTitle - $itemDesc - $price - $category<a href='inventory_edit.php?itemid=$itemid'>&bull;Edit</a> &bull;
      			 <a href='UpdateInventory.php?deleteid=$itemid'>Delete</a><br />";
       	echo ($product_list);
 }
} else {
 echo ('No products to display');
  }
 
?>

<?php
//Delete Item
if(isset($_GET['deleteid'])) {
	echo 'Are you sure you want to delete a menu item with ID ' . $_GET['deleteid'].
	'?<a href="UpdateInventory.php?yesdelete='.$_GET['deleteid'].'"> Yes </a>|
	<a href="UpdateInventory.php"> No</a>';
	exit();
}
if(isset($_GET['yesdelete'])) {
	//remove item from the database
	$itemid_todelete = $_GET['yesdelete'];
	$sql = "DELETE FROM Products WHERE ItemID='$itemid_todelete' LIMIT 1";
	$con = mysqli_connect ('localhost', 'root', 'root', 'class')
 		or die('Error connecting to MySQL server.');
	$result = mysqli_query($con, $sql);
	header("location: UpdateInventory.php");
exit();
}
?>
<a name="AddNewItem" id="AddNewItem"></a>
<h2 align="center">Add New Menu Item</h2>
<form action="UpdateInventory.php" enctype="multipart/form-data" method="post">
<table width="90%" border="0" cellspacing="10" cellpadding="5">
<tr>
	<td width="20%">Menu Item Title</td>
	<td width="60%"><label><input name="ItemTitle" type="text" id="itemtitle" size="30" />
	</label></td>
</tr>
<tr>
	<td>Menu Item Description</td>
	<td><label><input name="ItemDesc" type="text" id="ItemDesc" size="80" />
	</label></td>
</tr>
<tr>
	<td>Menu Item Price</td>
	<td><label>$<input name="Price" type="text" id="price" size="12" />
	</label></td>
</tr>
<tr>
	<td>Menu Item Category</td>
	<td><label><input name="category" type="text" id="category" size="20" />
	</label></td>
</tr>
<tr>
	<td>Product Image</td>
	<td><label><input name="fileField" type="file" id="fileField" />
	</label></td>
</tr>
<tr><td><input type="submit" value="Add New Item" />
	</td></tr>
</table>
</form>

<?php

if (isset($_POST['ItemTitle'])) {

	$title = trim($_POST['ItemTitle']);
	$desc = trim($_POST['ItemDesc']);
	$price = trim($_POST['Price']);
	$cat = trim($_POST['category']);

	//check if this title doesnt exist

	$sql= "SELECT ItemID FROM Products where ItemTitle='$title' LIMIT 1";

	$result = mysqli_query($con, $sql);

	$itemcount = mysqli_num_rows($result);

	if ($itemcount>0) {
		echo ('Sorry this item already exist. <a href="UpdateInventory.php">Click Here to continue</a>');
		exit();
	}

	//Add this menu item to the Menu table
	$sql = "INSERT INTO Products (ItemTitle, ItemDesc, Price, Category) VALUES ('$title', '$desc', '$price', '$cat')";
	$result = mysqli_query($con, $sql);
	$pid = mysqli_insert_id($con);
	echo($pid);
	//Place image in the folder
	$newname = "$pid.jpg";
	move_uploaded_file( $_FILES['fileField']['tmp_name'], "../images/$newname");

	}


?>
<?php  ?>

<?php include_once(""); //your website footer template?>

</body></html>