<?php
session_start();
if (!isset($_SESSION["manager"])) {
	header("location: admin_login.php");
	exit();
}

?>
<html><head><title>Admin Control Panel</title>
<link rel="stylesheet" href="style.css"></head><body>
<?php include_once("template_Header_members.php"); //your website header template?>
<h1>Administrative Panel</h1>
<hr />
<h3>Manage Inventory</h3>
<h3><a href="forgetpass.php">Reset Password</a></h3>
<h3><a href="updateinventory.php">Manage Inventory</a></h3>








<?php include_once("template_Footer.php"); //your website footer template?>
</body></html>