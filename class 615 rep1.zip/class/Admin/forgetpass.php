<?php
session_start();
?>

<?php
//Error Reporting
error_reporting(E_ALL);
ini_set('display_errors', '1');
?>

<html><head><title>Password Reset Page</title></head><body>
<h1>Reset smg!</h1>
<hr />
<form method="post" action="forgetpass1.php">
<p> Username:
<input type="text" name="user" placeholder="admin username">
<p>
<input type="submit" value="Reset"></p>
</form>



</body></html>      
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
      
      	