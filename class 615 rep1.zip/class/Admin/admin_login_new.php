<?php
session_start();

?>

<?php
//Error Reporting
error_reporting(E_ALL);
ini_set('display_errors', '1');
?>


<html><head><title>Admin Control Panel</title></head><body>
<h1>Please login to manage the store or create a <a href="adminnewaccount.php">New Account</a></h1>
<hr />
<form method="post" action="admin_login_new.php">
<p> Username:
<input type="text" name="user" placeholder="admin username">
Password:
<input type="password" name="pwd" placeholder="admin password">
</p>
<p>
<input type="submit" value="Login"></p>
</form>


<?php

   // Connect to the database
       $con = mysqli_connect ('localhost', 'root', 'root', 'class')
 		or die('Error connecting to MySQL server.');

    // Grab the user login data
      $username = trim($_POST['user']);
      $password = trim($_POST['pwd']);

     if (!empty($username) && !empty($password)) {
        // Look up the username and password in the database
        $query = "SELECT admin_user FROM admins WHERE admin_user = '$username' AND admin_pwd = '$password'";
        $result = mysqli_query($con, $query);

        if (mysqli_num_rows($result) == 1) {
           // Confirm the successful log-in
    	echo('<h2>Login Successful!</h2><h3><a href="adminhome.php">Click here to access Admin Control Panel</a></h3>');
    	$_SESSION['manager'] = $username;
    	setcookie('manager', $row['manager'], time() + (60 * 60 * 24 * 30));  // expires in 30 dclass
        }
        else {
          // The username/password are incorrect so set an error message
          	echo('<p> Sorry, you must enter a valid username and password to log in.');
			echo('<h3> <a href="forgetpass.php">Forgot Password.</a></h3>');
			//echo('<h3> <a href="adminnewaccount.php">Create New Account.</a></h3>');
        	}
		}else {
          // The username/password are incorrect so set an error message
          	echo('<p> Sorry, you must enter a valid username and password to log in.');
			echo('<h3> <a href="forgetpass.php">Forgot Password.</a></h3>');
			//echo('<h3> <a href="adminnewaccount.php">Create New Account.</a></h3>');
        	}
      

?>


</body></html>