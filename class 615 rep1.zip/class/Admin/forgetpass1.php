<?php
session_start();
?>

<?php
//Error Reporting
error_reporting(E_ALL);
ini_set('display_errors', '1');
?>
<html><head><title>Password Reset Page</title></head><body>
<h2> Reset your password here </h2>

<?php
	 $con = mysqli_connect ('localhost', 'root', 'root', 'class')
 		or die('Error connecting to MySQL server.');
 	 $username = trim($_POST['user']);
   
	if (!empty($username)) {
		$query = "SELECT admin_user FROM admins WHERE admin_user = '$username'";
		$result = mysqli_query($con, $query);
		if (mysqli_num_rows($result) == 1) {
		 	echo('<form method="post" action="forgetpass2.php">
			<p> Enter New Password:
			<input type="password" name="pwd" placeholder="new password">
			<p>
			<input type="hidden" name="user" value="'. $username.'">
			<input type="submit" value="Reset"></p>
			</form>');
		}
		else {
       			echo('<p> Sorry, you must enter a valid username to reset your password.');
       		} 
	}
	else {
       			echo('<p> Sorry, you must enter a valid username to reset your password.');
       		}
 ?>
</body></html>