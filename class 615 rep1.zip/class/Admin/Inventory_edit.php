<?php
session_start();
if (!isset($_SESSION["manager"])) {
	header("location: admin_login.php");
	exit();
	}
//Error Reporting
	error_reporting(E_ALL);
	ini_set('display_errors', '1');

?>

<html><head><title>Admin Control Panel</title></head><body>
<h1>Manage Inventory</h1>
<hr />
<h2>Edit menu item</h2>
<?php
//Display chosen menu item
if(isset($_GET['itemid'])) {

	$con = mysqli_connect ('localhost', 'root', 'root', 'class')
	or die('Error connecting to MySQL server.');
	$iid = $_GET['itemid'];

	$sql= "SELECT * FROM Products where ItemID = '$iid' LIMIT 1";
	$result = mysqli_query($con, $sql);
	if (mysqli_num_rows($result) == 1) {

		$row = mysqli_fetch_array($result);
       	$itemTitle = $row["ItemTitle"];
      	$itemDesc = $row["ItemDesc"];
     	$price = $row["Price"];
     	$category = $row["Category"];
		} else {
		echo ('No products to display');
  		}
	
	}
?>
<form action="Inventory_edit.php" enctype="multipart/form-data" method="post">
<table width="90%" border="0" cellspacing="10" cellpadding="5">
<tr>
	<td width="20%">Menu Item Title</td>
	<td width="60%"><label><input name="ItemTitle" type="text" value="<?php echo $itemTitle; ?>" id="itemtitle" size="30" />
	</label></td>
</tr>
<tr>
	<td>Menu Item Description</td>
	<td><label><input name="ItemDesc" type="text" value="<?php echo $itemDesc; ?>" id="ItemDesc" size="80" />
	</label></td>
</tr>
<tr>
	<td>Menu Item Price</td>
	<td><label>$<input name="Price" type="text" value="<?php echo $price; ?>" id="price" size="12" />
	</label></td>
</tr>
<tr>
	<td>Menu Item Category</td>
	<td><label><input name="category" type="text" value="<?php echo $category; ?>" id="category" size="20" />
	</label></td>
</tr>
<tr>
	<td>Product Image</td>
	<td><label><input name="fileField" type="file" id="fileField" />
	</label></td>
</tr>
<tr><td><input type="hidden" name="thisID" value="<?php echo $iid; ?>" />
<input type="submit" value="Update Item" />
	</td></tr>
</table>
</form>
<?php  
if (isset($_POST['ItemTitle'])) {
	
	$itemid = trim($_POST['thisID']);
	$title = trim($_POST['ItemTitle']);
	$desc = trim($_POST['ItemDesc']);
	$price = trim($_POST['Price']);
	$cat = trim($_POST['category']);
	$pid = $_POST['thisID'];
	
	$con = mysqli_connect ('localhost', 'root', 'root', 'class');
	//Update this menu item in the Menu table
	$sql = "UPDATE Products SET ItemTitle='$title', ItemDesc='$desc', Price='$price', Category='$cat' WHERE ItemId='$itemid' ";
	$result = mysqli_query($con, $sql);
	echo($pid);
	//Place image in the folder
	$newname = "$pid.jpg";
	move_uploaded_file( $_FILES['fileField']['tmp_name'], "images/$newname");

	header("location: UpdateInventory.php");
	exit();
	}

?>


</body></html>