<?php
session_start();
?>
<?php
//Error Reporting
	error_reporting(E_ALL);
	ini_set('display_errors', '1');
	
// remove all session variables
session_unset(); 

// destroy the session 
session_destroy(); 

//redirect to index.php page
header("location: admin_login.php");
?>
<!DOCTYPE html>
<html>
<body>
</body>
</html>

