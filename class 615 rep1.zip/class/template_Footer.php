</div>


    <footer class="footer">
      <div class="container">
        <a href="admin/adminhome.php">&copy;</a>2016 At Your Service
      </div>
    </footer>



    <!-- jQuery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
    <!-- Bootstrap JavaScript -->
    <script src="https://cdn.rawgit.com/twbs/bootstrap/v4-dev/dist/js/bootstrap.js"></script>
  </body>
</html>