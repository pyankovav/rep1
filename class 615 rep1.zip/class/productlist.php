<?php 
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
 
$con = new mysqli("localhost", "root", "root", "class");
 
$result = $con->query("SELECT * FROM products");
 
$outp = '{"products":[';
while($rs = $result->fetch_array(MYSQLI_ASSOC)) {
    if ($outp != '{"products":[') {$outp .= ',';}
    $outp .= '{"Title":"' .$rs["ItemTitle"] . '",';
    $outp .= '"Description":"' . $rs["ItemDesc"] . '",';
    $outp .= '"Price":"' . $rs["Price"] .'",';
    $outp .= '"Category":"' . $rs["Category"] . '"}';
}
$outp .="]}";
 
$con->close();
 
echo($outp);
 
/*
header('Content-Type: application/json');