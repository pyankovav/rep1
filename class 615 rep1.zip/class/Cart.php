<?php
//this section checks if user logged
session_start();
if (!isset($_SESSION["username"])) {
	header("location: UserLogin.php");
	exit();
	}
?>
<?php
//this section enables error handling
//error_reporting(E_ALL);
//ini_set('display_errors', '1');
?>

<?php
//this section creates shopping cart array

if(isset($_GET['id'])) {
	$itemid = $_GET['id'];
	$wasFound = false;
	$i = 0;

	//if the cart session variable is not set or cart array is empty
	if(!isset($_SESSION["cart_array"]) || count($_SESSION["cart_array"]) < 1) {
		//RUN if cart is empty or session is not set
			$_SESSION["cart_array"] = array(1 => array("itemid" => $itemid, "quantity" => 1));

	} else {
		//RUN if the cart has at least one item
		foreach ($_SESSION["cart_array"] as $each_item) {
			$i++;
			while (list($key, $value) = each($each_item)) {
				if($key == "itemid" && $value == $itemid) {
					//the item is already in the cart - adjust quantity
					array_splice($_SESSION["cart_array"], $i-1, 1, array(array("itemid" => $itemid, "quantity" => $each_item['quantity'] + 1)));
					$wasFound = true;
					}
				}
			}
			//new item added to the cart
			if($wasFound == false) {
				array_push($_SESSION["cart_array"], array("itemid" => $itemid, "quantity" => 1));
			}
		}
	}



?>

<?php
	////this section checks if user chooses to empty shopping cart
	if(isset($_GET['cmd']) && $_GET['cmd'] == "emptycart") {
		unset($_SESSION["cart_array"]);
		}

?>

<?php
	////this section checks if user chooses to adjust item quantity

	if (isset($_POST['item_to_adjust']) && $_POST['item_to_adjust'] != "") {
	    $item_to_adjust = $_POST['item_to_adjust'];
		$quantity = $_POST['quantity'];
		$quantity = preg_replace('#[^0-9]#i', '', $quantity); // filter everything but numbers
		if ($quantity >= 100) { $quantity = 99; }
		if ($quantity < 1) { $quantity = 1; }
		if ($quantity == "") { $quantity = 1; }
		$i = 0;
		foreach ($_SESSION["cart_array"] as $each_item) {
			      $i++;
			      while (list($key, $value) = each($each_item)) {
					  if ($key == "itemid" && $value == $item_to_adjust) {
						  // That item is in cart already so lets adjust its quantity using array_splice()
						  array_splice($_SESSION["cart_array"], $i-1, 1, array(array("itemid" => $item_to_adjust, "quantity" => $quantity)));
					  } // close if condition
			      } // close while loop
		} // close foreach loop
}
?>

<?php
	////this section checks if user chooses to remove an item from the shopping cart
if (isset($_POST['item_to_remove']) && $_POST['item_to_remove'] != "") {
    // Access the array and run code to remove that array index
	$key_to_remove = $_POST['item_to_remove'];
	if (count($_SESSION["cart_array"]) <= 1) {
		unset($_SESSION["cart_array"]);
	} else {
		unset($_SESSION["cart_array"]["$key_to_remove"]);
		sort($_SESSION["cart_array"]);
	}
}
?>

<?php
//Display Shopping Cart
$shoppingCart = "";
$product_id_array = "";
$cartTotal = "";
$priceTotal = "";
$pp_checkout_btn = "";

$con = mysqli_connect ('localhost', 'root', 'root', 'class')
		or die('Error connecting to MySQL server.');

if(!isset($_SESSION["cart_array"]) || count($_SESSION["cart_array"]) < 1) {
	$shoppingCart = "<h2 align='center'>Your shopping cart is empty</h2>";
}
else {
	// Start PayPal Checkout Button
	$pp_checkout_btn .= '<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
	    <input type="hidden" name="cmd" value="_cart">
	    <input type="hidden" name="upload" value="1">
    	<input type="hidden" name="business" value="you@youremail.com">';
	$i = 0;
	foreach ($_SESSION["cart_array"] as $each_item) {
		$itemid = $each_item['itemid'];
		$sql = "SELECT * FROM Products where ItemID ='$itemid' LIMIT 1";
		$result = mysqli_query($con, $sql);
		while ($row = mysqli_fetch_array($result)) {
			$itemtitle = $row['ItemTitle'];
			$price = $row['Price'];
		}
		$priceTotal = $price * $each_item['quantity'];
		$cartTotal = $priceTotal + $cartTotal;
		setlocale(LC_MONETARY, "en_US");
		$priceTotal = money_format("%10.2n", $priceTotal);
		// Dynamic Checkout Btn Assembly
		$x = $i + 1;
		$pp_checkout_btn .= '<input type="hidden" name="item_name_' . $x . '" value="' . $itemtitle . '">
		     <input type="hidden" name="amount_' . $x . '" value="' . $price . '">
        	<input type="hidden" name="quantity_' . $x . '" value="' . $each_item['quantity'] . '">  ';
		// Create the cart items array variable
		$product_id_array .= "$itemid-".$each_item['quantity'].",";
		// Dynamic shopping cart table display assembly
		$shoppingCart .= '<tr>';
		$shoppingCart .= '<td> Menu Item: ' .$itemtitle. '</td>&nbsp;';
		$shoppingCart .= '<td>Price: $' .$price. '</td>';
		$shoppingCart .= '<td><form action="cart.php" method="post">
		<input name="quantity" type="text" value="' . $each_item['quantity'] . '" size="1" maxlength="2" />
		<input name="adjustBtn' . $itemid . '" type="submit" value="change" />
		<input name="item_to_adjust" type="hidden" value="' . $itemid . '" />
		</form></td>';
		$shoppingCart .= '<td>' .$priceTotal. '</td>';
		$shoppingCart .= '<td><form action="cart.php" method="post"><input name="deleteBtn'
		. $itemid . '" type="submit" value="X" /><input name="item_to_remove" type="hidden" value="' . $i . '" /></form></td>';
		$shoppingCart .= '</tr>';
		//$shoppingCart .= '<td>' . $each_item['quantity'] . '</td>';
		$i++;
	}
		setlocale(LC_MONETARY, "en_US");
	    $cartTotal = money_format("%10.2n", $cartTotal);
		$cartTotal = "<div style='font-size:18px; margin-top:12px;' align='right'>Cart Total : ".$cartTotal." USD</div>";
		//echo ($cartTotal);
		// Finish the Paypal Checkout Btn
			$pp_checkout_btn .= '<input type="hidden" name="custom" value="' . $product_id_array . '">
			<input type="hidden" name="notify_url" value="https://www.yoursite.com/storescripts/my_ipn.php">
			<input type="hidden" name="return" value="https://www.yoursite.com/checkout_complete.php">
			<input type="hidden" name="rm" value="2">
			<input type="hidden" name="cbt" value="Return to The Store">
			<input type="hidden" name="cancel_return" value="https://www.yoursite.com/paypal_cancel.php">
			<input type="hidden" name="lc" value="US">
			<input type="hidden" name="currency_code" value="USD">
			<input type="image" src="http://www.paypal.com/en_US/i/btn/x-click-but01.gif" name="submit" alt="Make payments with PayPal - its fast, free and secure!">
	</form>';
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Shopping Cart</title>
<link rel="stylesheet" href="style/style.css" type="text/css" media="screen" />
</head>
<body>
<h1>Shopping Cart </h1><h1 align="right"><a href="OrderSelection.php">Back to Menu </a> </h1>
<div align="center" id="mainWrapper">
  <?php include_once("template_header.php");?>
  <div id="pageContent">
    <div style="margin:24px; text-align:left;">

    <br />
    <table width="100%" border="1" cellspacing="0" cellpadding="6">
      <tr>
        <td width="18%" bgcolor="#C5DFFA"><strong>Product</strong></td>
        <td width="10%" bgcolor="#C5DFFA"><strong>Unit Price</strong></td>
        <td width="9%" bgcolor="#C5DFFA"><strong>Quantity</strong></td>
        <td width="9%" bgcolor="#C5DFFA"><strong>Total</strong></td>
        <td width="9%" bgcolor="#C5DFFA"><strong>Remove</strong></td>
      </tr>

<?php echo $shoppingCart; ?>

 </table>
    <?php echo $cartTotal; ?>
     <br />
	<br />
<?php echo $pp_checkout_btn; ?>
 <br />
    <br />
<a href="cart.php?cmd=emptycart">Click Here to Empty Your Shopping Cart</a>
</div>
   <br />
  </div>
  <?php include_once("template_footer.php");?>
</div>
</body>
</html>
</body></html>

