<?php include_once("template_header.php"); ?>



<div ng-app="myApp" ng-controller="myCtrl" class="p-y-3"> 


  <div class="row">

    <div class="col-sm-3">
        <select ng-model="myVar" aria-label="ngSelected" class="form-control">
          <option value="Breakfast" ng-selected="selected">Breakfast</option>
          <option value="Lunch">Lunch</option>
          <option value="Dinner">Dinner</option>

          <!-- <option ng-repeat="x in myData" value="{{x.Category}}">{{x.Category}}</option> -->

        </select>
    </div>

    <div class="col-sm-9">




        <div ng-switch="myVar">
          <div ng-switch-when="Breakfast">
            <h1>Breakfast</h1>
            
            <table class="table table-striped">
            <tr ng-repeat="x in myData | filter:myVar">
                <td>{{ x.Title }}</td>
                <td>{{ x.Description }}</td>
                <td>{{ x.Price }}</td>
                <td>{{ x.Category }}</td>
            </tr>
            </table>

          </div>
          <div ng-switch-when="Lunch">
            <h1>Lunch</h1>
            
            <table class="table table-striped">
            <tr ng-repeat="x in myData | filter:myVar">
                <td>{{ x.Title }}</td>
                <td>{{ x.Description }}</td>
                 <td>{{ x.Price }}</td>
                 <td>{{ x.Category }}</td>
            </tr>
            </table>
          </div>
          <div ng-switch-when="Dinner">
            <h1>Dinner</h1>
            
            <table class="table table-striped">
            <tr ng-repeat="x in myData | filter:myVar">
                <td>{{ x.Title }}</td>
                <td>{{ x.Description }}</td>
                 <td>{{ x.Price }}</td>
                 <td>{{ x.Category }}</td>
            </tr>
            </table>
          </div>
          <div ng-switch-default>
          </div>
        </div>




</div>


    </div>

  </div>


<script>
var app = angular.module('myApp', []);
app.controller('myCtrl', function($scope, $http) {
  
  $http.get("productlist.php").then(function (response) {
      $scope.myData = response.data.products;
  });

});
</script>





<?php include_once("template_footer.php"); ?>

