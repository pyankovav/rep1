<?php
session_start();
?>

<?php
//Error Reporting
error_reporting(E_ALL);
ini_set('display_errors', '1');
?>


<html><head><title></title></head><body>
<h1>Please login:</h1>
<hr />
<form method="post" action="login.php">
<p> Username:
<input type="text" name="user" placeholder="username">
Password:
<input type="password" name="pwd" placeholder="password">
</p>
<p>
<input type="submit" value="Login"></p>
</form>


<?php

   // Connect to the database
       $con = mysqli_connect ('localhost', 'root', 'root', 'class')
 		or die('Error connecting to MySQL server.');

    // Grab the user login data
      $username = trim($_POST['user']);
      $password = trim($_POST['pwd']);

     if (!empty($username) && !empty($password)) {
        // Look up the username and password in the database
        $query = "SELECT email FROM customers WHERE email = '$username' AND password = '$password'";
        $result = mysqli_query($con, $query);

        if (mysqli_num_rows($result) == 1) {
           // Confirm the successful log-in
    	echo('<h2>Login Successful!</h2><h3><a href="clienthome_members.php">Click here to access our cafe</a></h3>');
    	$_SESSION['customer'] = $username;
    	setcookie('customer', $row['customer'], time() + (60 * 60 * 24 * 30));  // expires in 30 dclass
        }
        else {
          // The username/password are incorrect so set an error message
          	echo('<p> Sorry, you must enter a valid username and password to log in.');

        	}

      }

?>


</body></html>