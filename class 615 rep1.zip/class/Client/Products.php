<?php
session_start();
?>
<html>
<head>
</head>
<body>
<h1>Breakfast Menu </h1>
<table>
<?php

       $con = mysqli_connect ('localhost', 'root', 'root', 'class')
 		or die('Error connecting to MySQL server.');
 		
 		$query = "SELECT * FROM Products where Category='Breakfast'";
       $result = mysqli_query($con, $query);
        
        $itemcount = mysqli_num_rows($result);
       
       if ($itemcount>0) {
        while ($row = mysqli_fetch_array($result)) {
       	$itemid = $row["ItemID"];
       	$itemTitle = $row["ItemTitle"];
        $itemDesc = $row["ItemDesc"];
       	$price = $row["Price"];
        	
       	echo ('<tr><td>'. $itemid. '</td><td><a href="product_display.php?itemid='.$itemid. '">'. $itemTitle. '</td><td>'. 
        	$itemDesc. '</td><td>'. $price. '</td></tr>');
      	}
     } else {
     echo ('No products to display');
    }
       
 ?>
</table>

 <h1>Lunch Menu </h1>
 <table>
 <?php
 $query1 = "SELECT * FROM Products where Category='Lunch'";
  $result1 = mysqli_query($con, $query1);
  $itemcount1 = mysqli_num_rows($result1);
       
       if ($itemcount>0) {
        while ($row1 = mysqli_fetch_array($result1)) {
       	$itemid1 = $row1["ItemID"];
       	$itemTitle1 = $row1["ItemTitle"];
        $itemDesc1 = $row1["ItemDesc"];
       	$price1 = $row1["Price"];
        	
       	echo ('<tr><td>'. $itemid1. '</td><td><a href="product_display.php?itemid='.$itemid1. '">'. $itemTitle1. '</td><td>'. 
        	$itemDesc1. '</td><td>'. $price1. '</td></tr>');
      	}
     } else {
     echo ('No products to display');
    }
    ?>
    </table>
    <h1>Dinner Menu </h1>
     <table>
 <?php
 $query2 = "SELECT * FROM Products where Category='Dinner'";
  $result2 = mysqli_query($con, $query2);
  $itemcount2 = mysqli_num_rows($result2);
       
       if ($itemcount2>0) {
        while ($row2 = mysqli_fetch_array($result2)) {
       	$itemid2 = $row2["ItemID"];
       	$itemTitle2 = $row2["ItemTitle"];
        $itemDesc2 = $row2["ItemDesc"];
       	$price2 = $row2["Price"];
        	
       	echo ('<tr><td>'. $itemid2. '</td><td><a href="product_display.php?itemid='.$itemid2. '">'. $itemTitle2. '</td><td>'. 
        	$itemDesc2. '</td><td>'. $price2. '</td></tr>');
      	}
     } else {
     echo ('No products to display');
    }
    ?>
  </table> 
    </body></html>
    
       
