<div id="pageTop">
  <div id="pageTopWrap">
    <div id="pageTopLogo">
      <a href="http://www.class.com">
        <img src="images/logo.png" alt="logo" title="At Your Service">
      </a>
    </div>
    <div id="pageTopRest">
      <div id="menu1">
        <div>
          <a href="login.php">Login</a> | <a href="signup.php">Sign Up</a> 
        </div>
      </div>
      <div id="menu2">
        <div id="menu3">
          <a href="http://www.class.com">
            <img src="images/home.jpg" alt="home" title="Home">
          </a>
          
        </div>
      </div>
    </div>  
         <br />
         <br />
                  <br />
         <br />
                  <br />
         <br />
                  <br />
         <br />         <br />
         <br />
        </div>
      </div>
    </div>
  </div>
</div>

