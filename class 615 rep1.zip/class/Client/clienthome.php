<?php
//session_start();
//if (!isset($_SESSION["customer"])) {
//	header("location: login.php");
//	exit();
//}

?>
<html><head><title>Welcome to At Your Service Cafe</title>
<link rel="stylesheet" href="style.css"></head><body>
<?php include_once("template_Header.php"); //your website header template?>
<h1>Welcome to At Your Service Cafe</h1>
<hr />








<?php include_once("template_Footer.php"); //your website footer template?>
</body></html>