<?php
//session_start();
//if (!isset($_SESSION["username"])) {
//	header("location: account_login.php");
//	exit();
//}
?>
<?php
//Error Reporting
//error_reporting(E_ALL);
//ini_set('display_errors', '1');
?>
<?php
//check if itemid is set or exist in the database
if(isset($_GET['itemid'])) {
	$prodid = $_GET['itemid'];
	//$prodid = preg_replace('#[^0-9]#i', , $_GET['itemid']);
	
	$con = mysqli_connect ('localhost', 'root', 'root', 'class')
 		or die('Error connecting to MySQL server.');
 		$query = "SELECT * FROM Products where ItemID='$prodid' LIMIT 1";
      	$result = mysqli_query($con, $query);
       	$itemcount = mysqli_num_rows($result);
       
     if ($itemcount>0) {
      while ($row = mysqli_fetch_array($result)) {
     	$itemid = $row["ItemID"];
     	$itemTitle = $row["ItemTitle"];
        $itemDesc = $row["ItemDesc"];
    	$price = $row["Price"];
      	$cat = $row["Category"];
       	    
     }	
   }
 } else {
	echo "No product to display";
	exit();

mysql_close();
	

}

 
 ?>
<html>
<head>
<title> <?php echo $itemTitle; ?></title>
</head>
<body>
<h1><?php echo $itemTitle; ?> </h1>
<table width="100%" border="0" cellspacing="10" cellpadding="15">
<tr>
	<td width="20%" valign="top"><img src="images/<?php echo $itemid; ?>.jpg" width="140" height="180"><br />
	<a href="images/<?php echo $itemid; ?>.jpg">View the Full Size Image</a></td>
	<td width="80%" valign="top"><h3><?php echo $title; ?> </h3>
	<p><?php echo $itemDesc; ?><br />
	<?php echo $price; ?><br />
	<?php echo $cat; ?><br />
	<a href="Cart.php?id=<?php echo $itemid; ?>">Add to cart</a> 
	</td> </td></tr>

 
 
</table>
</body></html>