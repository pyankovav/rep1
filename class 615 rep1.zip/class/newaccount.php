<?php
session_start();
if (!isset($_SESSION["username"])) {
	header("location: UserLogin.php");
	exit();
}
?>
<?php
//Error Reporting
error_reporting(E_ALL);
ini_set('display_errors', '1');
?>
<?php
 	// Connect to the database
       $con = mysqli_connect ('localhost', 'root', 'root', 'class')
 		or die('Error connecting to MySQL server.');

			$username = trim($_POST['username']);
      		$password = trim($_POST['pass']);
      		$first = trim($_POST['fname']);
      		$last = trim($_POST['lname']);
      		
      		//echo $username, $password, $first, $last;
      		
      		
      		
			if (!empty($username) && !empty($password)) {
        	//Store username and password in the database
       		$query = "INSERT INTO customers (first, last, username, password) VALUES ('$first', '$last', '$username', '$password' )";
       		
       		$result1 = mysqli_query($con, $query);
       		
			echo('<h2> Dear, ' . $first. ' . Your Account has been successfully created!</h2>');  
       		
       		$query1 = "SELECT username FROM customers WHERE email = '$username' AND password = '$password'";
        	$result1 = mysqli_query($con, $query1);
       		if (mysqli_num_rows($result1) == 1) {
           
    		echo('<h2>Login Successful!</h2><h3>You are logged in as ' . $username . '.</h3>');
       		
       		}
       		else {
       		echo('<p> Sorry, you must enter a valid username and password to create account.');
       		}
       		}
       		else {
       		echo('<p> Sorry, you must enter a valid username and password to create account.');
       		}
       		
?>
